# Kerala Public School — Jaitrawas, Rewari

A standalone static HTML/CSS/JavaScript school website.

## Files
- index.html — complete page structure
- style.css — responsive styling and animations
- script.js — scroll reveal, progress bar, mobile menu
- README.md — this guide

## Important
School-specific facts, contact details, photos, achievements, admission dates and official notices are placeholders. Replace them with verified information before publishing.

## Free publishing
This is a static site, so it can be published with GitHub Pages or Cloudflare Pages. Both support static HTML; Cloudflare Pages provides a `*.pages.dev` subdomain after deployment.
